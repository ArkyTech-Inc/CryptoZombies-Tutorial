## Storage

This template constructs a skeleton contract that is used to persist values on the blockchain.
